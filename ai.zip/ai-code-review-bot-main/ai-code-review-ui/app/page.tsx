"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Sparkles } from "lucide-react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { okaidia } from "react-syntax-highlighter/dist/esm/styles/prism";

export default function CodeReviewPage() {
  const [code, setCode] = useState("");
  const [review, setReview] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isPRDiff, setIsPRDiff] = useState(false);

  const submitReview = async () => {
    if (!code.trim()) {
      setError("Please enter some code or PR diff to review");
      return;
    }

    setLoading(true);
    setReview("");
    setError("");

    try {
      const res = await fetch("http://localhost:8000/review/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, pr_diff: isPRDiff })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || err.error || "Review failed");
      }

      const data = await res.json();
      setReview(data.review || "No feedback returned.");
    } catch (err: any) {
      setError(`⚠️ ${err.message || "Something went wrong. Please try again."}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 to-slate-900 text-white flex items-center justify-center p-6">
      <Card className="w-full max-w-4xl rounded-2xl shadow-xl bg-slate-900/70 border border-slate-800">
        <CardContent className="p-8 space-y-6">
          <div className="flex items-center gap-3">
            <Sparkles className="text-indigo-400" />
            <h1 className="text-2xl font-semibold text-white">AI Code Review Bot</h1>
          </div>

          <p className="text-slate-400 text-sm">
            Paste your code or PR diff below. The AI will review it like a senior engineer.
          </p>

          {/* PR Diff Toggle */}
          <div className="flex items-center gap-2 mb-2">
            <input
              type="checkbox"
              checked={isPRDiff}
              onChange={(e) => setIsPRDiff(e.target.checked)}
              id="pr-diff-toggle"
              className="accent-indigo-400"
            />
            <label htmlFor="pr-diff-toggle" className="text-slate-400 text-sm">
              This is a PR diff
            </label>
          </div>

          <Textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Paste code or git diff here…"
            className="min-h-[220px] bg-slate-950 border-slate-700 text-slate-100 font-mono text-sm"
          />

          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Supports Python, JS, diffs, configs
            </span>

            <Button
              onClick={submitReview}
              disabled={loading || !code.trim()}
              className="rounded-xl px-6"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="animate-spin" size={16} /> Reviewing
                </span>
              ) : (
                "Review Code"
              )}
            </Button>
          </div>

          {error && (
            <div className="bg-red-950/50 border border-red-900/50 rounded-lg p-4">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {review && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">
              <h2 className="font-medium mb-4 text-indigo-300 flex items-center gap-2">
                <Sparkles size={18} />
                AI Feedback {isPRDiff && "(PR Diff Mode)"}
              </h2>

              {/* Syntax highlighted review */}
              <SyntaxHighlighter
                language={isPRDiff ? "diff" : "python"}
                style={okaidia}
                showLineNumbers
                wrapLines
                className="rounded-lg"
              >
                {review}
              </SyntaxHighlighter>
            </div>
          )}

          {loading && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 flex items-center justify-center">
              <div className="text-center py-8">
                <Loader2 className="animate-spin mx-auto mb-3 text-indigo-400" size={32} />
                <p className="text-slate-400">Analyzing your code...</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
